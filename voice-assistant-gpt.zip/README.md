# 🗣️ Python Voice Assistant

A Python voice assistant using OpenAI, speech recognition, and pyttsx3.

## Features
- Listens to your voice
- Responds using ChatGPT
- Speaks back the answer
- Can open websites like Google, YouTube

## How to Run
```bash
pip install -r requirements.txt
python main.py
```

## Author
Mukil