import speech_recognition as sr
import pyttsx3
import datetime
import webbrowser
import openai

# 🧠 Add your OpenAI API key
openai.api_key = "YOUR_API_KEY_HERE"

# 🔊 Text-to-Speech Engine
engine = pyttsx3.init()

def speak(text):
    engine.say(text)
    engine.runAndWait()

def greet():
    hour = datetime.datetime.now().hour
    if 0 <= hour < 12:
        speak("Good morning!")
    elif 12 <= hour < 18:
        speak("Good afternoon!")
    else:
        speak("Good evening!")
    speak("I am your assistant. How can I help you?")

def get_audio():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Listening...")
        audio = recognizer.listen(source)
    try:
        print("🧠 Recognizing...")
        return recognizer.recognize_google(audio)
    except sr.UnknownValueError:
        speak("Sorry, I didn't understand.")
        return ""
    except sr.RequestError:
        speak("Sorry, there was a problem with the service.")
        return ""

def chat_with_gpt(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    reply = response['choices'][0]['message']['content']
    speak(reply)
    print("GPT:", reply)

def main():
    greet()
    while True:
        command = get_audio().lower()
        if "stop" in command or "exit" in command:
            speak("Goodbye!")
            break
        elif "open youtube" in command:
            speak("Opening YouTube.")
            webbrowser.open("https://youtube.com")
        elif "open google" in command:
            speak("Opening Google.")
            webbrowser.open("https://google.com")
        elif command:
            chat_with_gpt(command)

if __name__ == "__main__":
    main()